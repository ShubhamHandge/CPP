

#include <iostream>

using namespace std;

int main()
{   string word;
    cout<<"who you are?";
     getline(cin,line);        
    // cin>>word;
   cout<<" you are: "<<word;
    return 0;
}
