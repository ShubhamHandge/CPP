#include <iostream>
using namespace std;
//1,2,3.......n

int main()
{
	int i,n;
	cout<<"Enter n:";
	cin>>n;
	i=1;
	while(i<=n)
	{
	  	cout<<i<<",";
	  	i++;
	}
}