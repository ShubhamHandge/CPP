int main()
{
	int i,j;
	i=1;
	j=9;
    for(i=1,j=9;i<=9 && j>=1;i++,j--)
    {
    cout<<i<<"+"<<j<<"="<<i+j<<"\n";
    }
    return 0;
}
