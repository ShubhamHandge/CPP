/*

// XXXXX
// XXXX
// XXX
// XX
// X

#include<iostream>
using namespace std;
int main()
{
	int i,j;
	for(i=5;i>=1;i--)
	{
		for(j=1; j<=i ;j++)
		{
			cout<<"x";		
		}
		cout<<"\n";
	}	
	
}
*/
/*
// 1
// 22
// 333
// 4444
// 55555

#include<iostream>
using namespace std;
int main()
{
	int i,j;
	for(i=1;i<=5;i++)
	{
		for(j=1; j<=i ;j++)
		{
			cout<<i;		
		}
		cout<<"\n";
	}	
	
	
}
*/
/*
//     X
//    XX
//   XXX
//  XXXX
// XXXXX

#include<iostream>
using namespace std;
int main()
{
	int i,j,space,s;
	for(space=5,i=1;space>=1 && i<=5 ;space--,i++)
	{  
	    for(s=1; s<=space ;s++)
       	{
			cout<<" ";		
		}
	
		for(j=1; j<=i ;j++)
		{
			cout<<"X";		
		}
		cout<<"\n";
	}	
	
	
}
*/
/*
// XXXXX
//  XXXX
//   XXX
//    XX
//     X

#include<iostream>
using namespace std;
int main()
{
	int i,j,space,s;
	for(space=1,i=5;space<=5 && i>=1 ;space++,i--)
	{  
	    for(s=1; s<=space ;s++)
       	{
			cout<<" ";		
		}
	
		for(j=1; j<=i ;j++)
		{
			cout<<"X";		
		}
		cout<<"\n";
	}	
	
	
}
*/
/*
//     1A
//    12AB
//   123ABC
//  1234ABCD
// 12345ABCDE
#include<iostream>
using namespace std;
int main()
{
	char i,j;
	int space,s,k,l;
	for(space=5,k=1 ,i='A';space>=1 && k<=5 && i<='E' ;space--,k++,i++)
	{  
	    for(s=1; s<=space ;s++)
       	{
			cout<<" ";		
		}

     	for(l=1; l<=k ;l++)
		{
			cout<<l;		
		}

		for(j='A'; j<=i ;j++)
		{
			cout<<j;		
		}
		cout<<"\n";
	}	

}
*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/
/*

*/