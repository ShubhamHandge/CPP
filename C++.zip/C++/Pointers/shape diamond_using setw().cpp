#include<iostream>
#include<iomanip>
using namespace std;
int main()
{   int i;
	cout<<end1<<" XXXX ";
	for(i=1;i<=5;i++)
	{
	   cout<<"X"<<set(5)<<"X"<<end1;
		
   	}
	cout<<end1<<" XXXX ";
	return 0;	
}